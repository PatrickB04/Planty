/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_e_events`; */
/* PRE_TABLE_NAME: `1697831909_wp_e_events`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1697831909_wp_e_events` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `event_data` text COLLATE utf8mb4_unicode_520_ci, `created_at` datetime NOT NULL, PRIMARY KEY (`id`), KEY `created_at_index` (`created_at`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1697831909_wp_e_events` (`id`, `event_data`, `created_at`) VALUES (1,'{\"event\":\"modal load\",\"version\":\"\",\"details\":\"{\\\"placement\\\":\\\"Onboarding wizard\\\",\\\"step\\\":\\\"account\\\",\\\"user_state\\\":\\\"anon\\\"}\",\"ts\":\"2023-10-17T12:05:13.879-02:00\"}','2023-10-17 12:05:14'),(2,'{\"event\":\"close modal\",\"version\":\"\",\"details\":\"{\\\"placement\\\":\\\"Onboarding wizard\\\",\\\"step\\\":\\\"account\\\"}\",\"ts\":\"2023-10-17T12:05:18.434-02:00\"}','2023-10-17 12:05:18');
