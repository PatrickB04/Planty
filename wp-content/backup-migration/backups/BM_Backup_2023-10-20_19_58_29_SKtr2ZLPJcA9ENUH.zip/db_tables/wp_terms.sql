/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_terms`; */
/* PRE_TABLE_NAME: `1697831909_wp_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1697831909_wp_terms` ( `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `term_group` bigint(10) NOT NULL DEFAULT '0', PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1697831909_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Non classé','non-classe',0),(2,'landing-page','landing-page',0),(3,'page','page',0),(4,'nav-header','nav-header',0),(5,'twentytwentythree','twentytwentythree',0),(6,'header','header',0),(7,'2021-child','2021-child',0),(8,'2023-child','2023-child',0),(9,'footer','footer',0);
