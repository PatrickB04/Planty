/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1697831909_wp_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1697831909_wp_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT '0', `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0', `term_order` int(11) NOT NULL DEFAULT '0', PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1697831909_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (14,2,0),(16,2,0),(17,2,0),(22,3,0),(49,4,0),(58,5,0),(59,5,0),(59,6,0),(61,7,0),(62,8,0),(63,8,0),(64,6,0),(64,8,0),(65,8,0),(65,9,0);
